- Data of provinces and cities are in Thai language.
- Geocodes are not real, just for importing by Base Location Geonames Import
- Prepared data from
https://www.bot.or.th/Thai/Statistics/DataManagementSystem/Standard/StandardCode/Pages/default.aspx


Poonlap V.
Dec 8, 2019
